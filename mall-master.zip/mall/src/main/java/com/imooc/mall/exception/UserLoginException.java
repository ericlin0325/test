package com.imooc.mall.exception;

/**
 * Created by 廖师兄
 */
public class UserLoginException extends RuntimeException {
}
